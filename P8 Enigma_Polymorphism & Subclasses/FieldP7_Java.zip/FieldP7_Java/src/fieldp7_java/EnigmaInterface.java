/**************************************************************************
 * Alix Field           afield@cnm.edu              FieldP7_Java
 * Enigma Program
 * 
 * Program Objective: Encoding & Decoding Strings
 **************************************************************************/
package fieldp7_java;


public interface EnigmaInterface {
    
 
    public void setMessage(String message);
    public void setMessage(String userMessag, int key);
    public void setCodedMessage(String codedMessage, int key);
    
    //public String getMessage();
    public String getCodedMessage();
    public String getDecodedMessage();
    public int getKey();    
}
