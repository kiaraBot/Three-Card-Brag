/**************************************************************************
 * Alix Field           afield@cnm.edu              FieldP7_Java
 * Enigma Program
 * 
 * Program Objective: Encoding & Decoding Strings
 **************************************************************************/
package fieldp7_java;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javax.swing.JFileChooser;


public class FXMLDocumentController implements Initializable {
    private Enigma enigma;    
    
    // ----------------------------------
    // Private Variables
    // ----------------------------------
    
    // Containers
    @FXML
    private AnchorPane anpaneEnigma;
    @FXML
    private VBox vbxBase;
    @FXML
    private HBox hbxInstructions;    
    @FXML
    private HBox hbxKeyMessage;
    @FXML
    private HBox hbxButtons;
    @FXML
    private HBox hbxKeyCodeMessageDIsplay;
    @FXML
    private VBox vbxSummaryLabels;
    @FXML
    private VBox vbxSummaryTextFields;    
    
    // Menu Bar
    @FXML
    private Menu mlbEnigmaInfo;
    @FXML
    private MenuItem mbEncodingInfo;
    @FXML
    private MenuBar mbarEnigma;
    @FXML
    private Menu mlbFile;
    @FXML
    private MenuItem mbOpenFile;
    @FXML
    private MenuItem mbSaveFile;
    @FXML
    private MenuItem mbCloseEnigma;
    @FXML
    private MenuItem mbDecodingInfo;
    
    // Labels
    @FXML
    private Label lbTitle;    
    @FXML
    private Label lbEncodeInstruct;
    @FXML
    private Label lbDecodeInstruct;
    @FXML
    private Label lbEnterKey;
    @FXML
    private Label lbEnterMessage;
    @FXML
    private Label lbMessageSummary;
    @FXML
    private Label lbMessage;
    @FXML
    private Label lbCodedMessage;
    @FXML
    private Label lbKey;
    
    // Text Fields
    @FXML
    private TextField txfUserKey;    
    @FXML
    private TextField txfMessageEntered;
    @FXML
    private TextField txfMessage;
    @FXML
    private TextField txfCodedMessage;
    @FXML
    private TextField txfKeyUsed;
        
    // Buttons
    @FXML
    private Button btnEncode;
    @FXML
    private Button btnDecode;
    @FXML
    private Button btnClear;
    @FXML
    private RadioButton rbtnGeneratedKey;
    @FXML
    private RadioButton rbtnUserKey;               
    
    // Primitive Variable Delcerations
    private String codedMessage;
    private int key;



    public FXMLDocumentController() {
        enigma = new Enigma();
                
        txfUserKey = new TextField();
        txfMessageEntered = new TextField();        
        txfMessage = new TextField();
        txfCodedMessage = new TextField();
        txfKeyUsed = new TextField();
        lbEncodeInstruct = new Label();
    }

    private int getUserKey(){
        key = Integer.parseInt(txfUserKey.getText());
        if(key > Enigma.KEY_MAX || key < Enigma.KEY_MIN){
          lbEncodeInstruct.setText("Error! Key Out of Bounds!" + 
                  "\r\nKey must be a number from 1 - 50!");
        }
        return key;
    }
    
    private void clear(){
        codedMessage = "";
        key = 10;
        txfUserKey.setText(Integer.toString(key));
        txfMessageEntered.setText("");
        txfMessage.setText("");
        txfCodedMessage.setText("");
        txfKeyUsed.setText("");
        rbtnGeneratedKey.setSelected(false);
        rbtnUserKey.setSelected(false);           
    }
    // ------------------------------------
    // Event Handlers
    // ------------------------------------    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        clear();
    }    
    
    // Encode Message
    @FXML
    private void handleBtnEncodeAction(ActionEvent event) {
        if(rbtnUserKey.isSelected()){
            enigma.setMessage(txfMessageEntered.getText(), getUserKey());       
            codedMessage = enigma.getCodedMessage();
            txfCodedMessage.setText(codedMessage);                  
            txfKeyUsed.setText(Integer.toString(enigma.getKey()));
            txfMessage.setText(txfMessageEntered.getText());
        }
        else if(rbtnGeneratedKey.isSelected())
        {
            enigma.setMessage(txfMessageEntered.getText());
            codedMessage = enigma.getCodedMessage();
            txfCodedMessage.setText(codedMessage);
            txfKeyUsed.setText(Integer.toString(enigma.getKey()));
            txfMessage.setText(txfMessageEntered.getText());
        }                        
    }
    
    // Decode Coded Message
    @FXML
    private void handleBtnDecodeAction(ActionEvent event) {
        if(rbtnUserKey.isSelected())
        {
            enigma.setCodedMessage(txfMessageEntered.getText(), getUserKey());
            codedMessage = enigma.getDecodedMessage();
            txfMessage.setText(codedMessage);      
            txfUserKey.setText(Integer.toString(enigma.getKey()));
            txfCodedMessage.setText(txfMessageEntered.getText());
        }
        else if(rbtnGeneratedKey.isSelected()){
            enigma.setMessage(txfMessageEntered.getText());
            codedMessage = enigma.getDecodedMessage();
            txfMessage.setText(codedMessage);
            txfKeyUsed.setText(Integer.toString(enigma.getKey()));
            txfCodedMessage.setText(txfMessageEntered.getText());
        }        
    }
    // Clear Form
    @FXML
    private void handleBtnClearAction(ActionEvent event) {
        clear();
    }

    // Radio Button Key Change
    @FXML
    private void handleUserKeyChange(MouseEvent event) {
            if(rbtnUserKey.isSelected())
                rbtnGeneratedKey.setSelected(false);
            if(rbtnGeneratedKey.isSelected()){
                rbtnUserKey.setSelected(false);
        }
    }
    
    // Enigma Information via MenuBar    
    @FXML
    private void handleMenuCodingInfoAction(ActionEvent event) {
        lbEncodeInstruct.setText("Encoding Instructions" + "\r\nEnter a message in the text box below" + 
                "\r\nSelect the Generated or the User Key 1- 50" + "\r\nPress the Encode Button Below" + 
                "\r\nSelect File > Save File to save the message");
    }

    @FXML
    private void handleMenuDecodingInfoAction(ActionEvent event) {
        lbDecodeInstruct.setText("Decoding Instructions" + "\r\nSelect File > Open File" + 
                "\r\nThen browse to your file to read the coded message" + "\r\nPress the Decode Button");
    }

    
    // Open File
    @FXML
    private void handleMenuOpenFileAction(ActionEvent event) {
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setDialogTitle("Open A File to be Decoded");       
        fileChooser.setCurrentDirectory(new java.io.File("."));
        String filename = "";

        int status = fileChooser.showOpenDialog(null);
        if(status == JFileChooser.APPROVE_OPTION)
        {
            try {               //read in the coded message and other input               
                File selectedFile = fileChooser.getSelectedFile();
                filename = selectedFile.getPath();
                File myFile = new File(filename);
                try (Scanner inputFile = new Scanner(myFile)) {
                    codedMessage = inputFile.nextLine();
                    key = inputFile.nextInt();
                }
            } 
            catch (IOException ex) {
               Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);            }
            }
    } 

    // Save File
    @FXML
    private void handleMenuSaveFileAction(ActionEvent event) {
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setCurrentDirectory(new java.io.File("."));
        fileChooser.setDialogTitle("Save Encoded Message");
        int status = fileChooser.showSaveDialog(null);
        String filename = "";

        if(status == JFileChooser.APPROVE_OPTION)
        {
            PrintWriter outputFile = null;
            try {

                File selectedFile = fileChooser.getSelectedFile();
                filename = selectedFile.getPath();  
                outputFile = new PrintWriter(filename);
                outputFile.println(enigma.getCodedMessage());             
                outputFile.println(key);                

                outputFile.close();
            } catch (IOException ex) {
                Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);            }
            }
    }

    // Close Enigma Program from Menu Bar Item Option
    @FXML
    private void handleMenuCloseEnigmaProgramAction(ActionEvent event) {
        System.exit(0);
    } // End Event Handlers


} // End FXMLDocumentController Class

